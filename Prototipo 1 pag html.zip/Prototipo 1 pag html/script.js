var map = L.map('map').setView([5.0386, -73.9013], 13);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);
var marker = L.marker([5.0386, -73.9013]).addTo(map);
marker.bindPopup("<b>Altiplano cundiboyacense</b><br>").openPopup();
var marker = L.marker([6.5152, -72.1527]).addTo(map);
marker.bindPopup("<b>Sierra nevada del cocuy</b>").openPopup();
var marker = L.marker([5.5241879, -73.1308554]).addTo(map);
marker.bindPopup("<b>Paramo la cortadera</b>").openPopup();
var popup = L.popup();

function onMapClick(e) {
    popup
        .setLatLng(e.latlng)
        .setContent("You clicked the map at " + e.latlng.toString())
        .openOn(map);
}

map.on('click', onMapClick);
